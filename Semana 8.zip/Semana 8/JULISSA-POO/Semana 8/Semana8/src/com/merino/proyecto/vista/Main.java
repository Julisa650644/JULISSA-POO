package com.merino.proyecto.vista;

import com.merino.proyecto.dashboard.Dashboard;

public class Main {
    public static void main(String[] args) {
        Dashboard dashboard = new Dashboard();
        dashboard.mostrarBienvenida();
        dashboard.iniciarMenu();
    }
}
