package com.merino.proyecto.dashboard;

import java.util.Scanner;
import java.util.ArrayList;
import java.util.List;

/**
 * Clase principal que muestra el menú del proyecto.
 * Permite registrar tareas simuladas y mostrar mensajes básicos.
 * @author Merino
 */
public class Dashboard {

    private List<String> tareas;

    public Dashboard() {
        this.tareas = new ArrayList<>();
    }

    /**
     * Muestra el mensaje de bienvenida.
     */
    public void mostrarBienvenida() {
        System.out.println("=== Bienvenido al Proyecto POO en Java ===");
    }

    /**
     * Inicia el menú principal del sistema.
     */
    public void iniciarMenu() {
        Scanner scanner = new Scanner(System.in);
        int opcion;

        do {
            System.out.println("\n--- MENÚ PRINCIPAL ---");
            System.out.println("1. Registrar tarea");
            System.out.println("2. Ver tareas");
            System.out.println("3. Estado del proyecto");
            System.out.println("0. Salir");
            System.out.print("Seleccione una opción: ");
            opcion = scanner.nextInt();
            scanner.nextLine(); // Limpiar buffer

            switch (opcion) {
                case 1:
                    System.out.print("Ingrese una tarea: ");
                    String tarea = scanner.nextLine();
                    registrarTarea(tarea);
                    break;
                case 2:
                    mostrarTareas();
                    break;
                case 3:
                    mostrarEstado();
                    break;
                case 0:
                    System.out.println("Saliendo del sistema...");
                    break;
                default:
                    System.out.println("Opción no válida.");
            }

        } while (opcion != 0);

        scanner.close();
    }

    private void registrarTarea(String tarea) {
        tareas.add(tarea);
        System.out.println("Tarea registrada con éxito.");
    }

    private void mostrarTareas() {
        if (tareas.isEmpty()) {
            System.out.println("No hay tareas registradas.");
        } else {
            System.out.println("Tareas registradas:");
            for (String t : tareas) {
                System.out.println("- " + t);
            }
        }
    }

    private void mostrarEstado() {
        System.out.println("Proyecto en desarrollo. Tareas registradas: " + tareas.size());
    }
}